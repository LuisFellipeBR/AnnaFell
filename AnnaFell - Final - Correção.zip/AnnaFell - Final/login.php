<?php
if(!isset($_SESSION)) {
    session_start();
}

$mensagem = '';
if (isset($_GET['cadastro']) && $_GET['cadastro'] == 'ok') {
    $mensagem = '<p class="af-msg-sucesso">✅ Cadastro realizado com sucesso! Faça login.</p>';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>
            <a href="index.php">Produtos</a>
            <a href="carrinho.php">Carrinho</a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <div class="af-form-box">
        <h2>Login</h2>
        <?php echo $mensagem; ?>
        <form method="POST" action="processa_login.php">
            <div class="af-campo">
                <label>Login:</label>
                <input type="text" name="login" required>
            </div>
            <div class="af-campo">
                <label>Senha:</label>
                <input type="password" name="senha" required>
            </div>
            <button type="submit" class="af-btn">Entrar</button>
        </form>
        <div class="af-botoes-laterais">
            <a class="af-btn-login" href="cadastro1.php">Cadastrar novo usuário</a>
            <a class="af-btn-login" href="index.php">Voltar à loja</a>
        </div>
    </div>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>