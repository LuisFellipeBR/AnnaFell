<?php
if(!isset($_SESSION)) {
    session_start();
}
include "cons.php";
require_once "DLL.php";

if (!isset($_SESSION['usuario_logado']) || empty($_SESSION['carrinho'])) {
    header("Location: index.php");
    exit();
}

extract($_POST);

$carrinho = $_SESSION['carrinho'];
$usuario = $_SESSION['usuario_logado'];
$cpf = $_SESSION['cpf_usuario'];

$consulta_nome = "SELECT nome FROM usuarios WHERE cpf = '$cpf'";
$resultado_nome = banco($server, $user, $password, $db, $consulta_nome);
$nome_completo = "";
if ($linha = $resultado_nome->fetch_assoc()) {
    $nome_completo = $linha['nome'];
}

$numero_venda = date("YmdHis") . rand(100, 999);
$data = date("Y-m-d");
$hora = date("H:i:s");
$total = 0;
foreach ($carrinho as $item) {
    $total += $item['preco'] * $item['quantidade'];
}

$sql_venda = "INSERT INTO vendas (numero, cpf_cliente, data, hora, pagamento, total) 
              VALUES ('$numero_venda', '$cpf', '$data', '$hora', '$pagamento', '$total')";
$res_venda = banco($server, $user, $password, $db, $sql_venda, true);

$id_venda = $res_venda->conn->insert_id;

foreach ($carrinho as $item) {
    $subtotal = $item['preco'] * $item['quantidade'];
    $sql_item = "INSERT INTO vendas_itens (id_venda, produto, quantidade, preco_unitario, subtotal) 
                 VALUES ($id_venda, '{$item['nome']}', {$item['quantidade']}, {$item['preco']}, $subtotal)";
    if (!$res_venda->conn->query($sql_item)) {
        echo "Erro ao inserir item: " . $res_venda->conn->error;
        exit();
    }
}

$res_venda->conn->close();

unset($_SESSION['carrinho']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Compra Finalizada - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>
            <a href="index.php">Produtos</a>
            <a href="carrinho.php">Carrinho</a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <div class="af-form-box af-mensagem-sucesso">
        <h2>🎉 Compra Realizada com Sucesso!</h2>
        <div class="af-agradecimento">
            <p>Olá, <strong><?php echo $nome_completo; ?></strong>!</p>
            <p>Muito obrigado pela sua compra na <strong>AnnaFell</strong>.</p>
            <p>Seu pedido foi registrado com o número: <strong class="af-numero-venda"><?php echo $numero_venda; ?></strong></p>
            <p>Em breve você receberá um e-mail com os detalhes da entrega.</p>
            <p>🌟 Aproveite seus novos produtos e volte sempre!</p>
        </div>
        <a href="index.php" class="af-btn">Continuar Comprando</a>
    </div>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>