<?php
// produtos.php - Lista completa de produtos da loja AnnaFell
// Imagens organizadas em subpastas dentro de img/

function getProdutos() {
    $produtos = [

        // ========== MONITORES ==========
        1 => [
            'id' => 1, 'nome' => 'Monitor Gamer Samsung Odyssey G30 24"',
            'descricao' => 'Monitor 24" Full HD, 75Hz, painel IPS',
            'preco' => 775.00, 'imagem' => 'img/Monitores/mon1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        2 => [
            'id' => 2, 'nome' => 'Monitor Gamer Acer Nitro VG240Y 23.8"',
            'descricao' => '23.8" LED IPS, 1ms, 165Hz, FreeSync',
            'preco' => 789.57, 'imagem' => 'img/Monitores/mon2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        3 => [
            'id' => 3, 'nome' => 'Monitor LG LED HD 20MK400H-B 19.5"',
            'descricao' => '19.5" HD, HDMI, VGA, 2ms, 75Hz',
            'preco' => 449.00, 'imagem' => 'img/Monitores/mon3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        4 => [
            'id' => 4, 'nome' => 'Monitor Gamer Curvo KOZZ 27" 144Hz',
            'descricao' => '27" Curvo Full HD, 144Hz, 1ms, HDMI',
            'preco' => 703.99, 'imagem' => 'img/Monitores/mon4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        5 => [
            'id' => 5, 'nome' => 'Monitor Gamer AOC AGON G42 27" 200Hz',
            'descricao' => '27" IPS, 200Hz, 0,3ms, HDR10, Full HD',
            'preco' => 999.99, 'imagem' => 'img/Monitores/mon5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        6 => [
            'id' => 6, 'nome' => 'Monitor Gamer Gigabyte GS24F14 23.8"',
            'descricao' => '23.8" Full HD, 144Hz, 1ms, painel IPS',
            'preco' => 711.90, 'imagem' => 'img/Monitores/mon6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        7 => [
            'id' => 7, 'nome' => 'Monitor Login M215 LED 21.5"',
            'descricao' => '21.5" Full HD, 60Hz, LED',
            'preco' => 379.05, 'imagem' => 'img/Monitores/mon7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        8 => [
            'id' => 8, 'nome' => 'Monitor LED Padrão VESA 19"',
            'descricao' => 'Monitor 19" LED, suporte VESA, diversos tamanhos',
            'preco' => 959.90, 'imagem' => 'img/Monitores/mon8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        9 => [
            'id' => 9, 'nome' => 'Monitor Gamer Curvo PCFort U27f280 27"',
            'descricao' => '27" Curvo Full HD, 280Hz, 1ms, LED',
            'preco' => 899.00, 'imagem' => 'img/Monitores/mon9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],
        10 => [
            'id' => 10, 'nome' => 'Monitor Gamer UltraGear LG 180Hz',
            'descricao' => '27" IPS, 180Hz, 1ms, FreeSync, G-SYNC',
            'preco' => 836.07, 'imagem' => 'img/Monitores/mon10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'monitores'
        ],

        // ========== TECLADOS ==========
        11 => [
            'id' => 11, 'nome' => 'Teclado Mecânico Gamer Husky Blizzard',
            'descricao' => 'Teclado mecânico ABNT2, switch Husky, branco, RGB',
            'preco' => 289.90, 'imagem' => 'img/Teclados/tec1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        12 => [
            'id' => 12, 'nome' => 'Teclado Multilaser Slim Preto USB',
            'descricao' => 'Teclado slim USB, ABNT2, preto',
            'preco' => 32.00, 'imagem' => 'img/Teclados/tec2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        13 => [
            'id' => 13, 'nome' => 'Teclado Gamer Redragon Kumara Elite',
            'descricao' => 'Teclado mecânico, switches Red, RGB, ABNT2',
            'preco' => 249.88, 'imagem' => 'img/Teclados/tec3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        14 => [
            'id' => 14, 'nome' => 'Teclado Warrior Royal Precision',
            'descricao' => 'Teclado mecânico com iluminação RGB',
            'preco' => 265.30, 'imagem' => 'img/Teclados/tec4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        15 => [
            'id' => 15, 'nome' => 'Teclado Magnético Gamer Redragon Dharma RGB',
            'descricao' => 'Teclado magnético, switches HE, RGB',
            'preco' => 389.99, 'imagem' => 'img/Teclados/tec5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        16 => [
            'id' => 16, 'nome' => 'Teclado Magnético Gamer Attack Shark X65 HE',
            'descricao' => 'Teclado magnético, switch HE, ABNT2',
            'preco' => 206.63, 'imagem' => 'img/Teclados/tec6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        17 => [
            'id' => 17, 'nome' => 'Teclado Mecânico 75% Pcyes Arkeum',
            'descricao' => 'Teclado mecânico compacto 75%, hot swap',
            'preco' => 167.31, 'imagem' => 'img/Teclados/tec7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        18 => [
            'id' => 18, 'nome' => 'Teclado Logitech K120 USB',
            'descricao' => 'Teclado USB ABNT2, resistente a respingos',
            'preco' => 75.05, 'imagem' => 'img/Teclados/tec8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        19 => [
            'id' => 19, 'nome' => 'Teclado Gamer Redragon Dyaus 2 RGB',
            'descricao' => 'Teclado membrana ABNT2 com RGB',
            'preco' => 127.71, 'imagem' => 'img/Teclados/tec9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],
        20 => [
            'id' => 20, 'nome' => 'Teclado Multimídia Com Fio USB KP-TE145',
            'descricao' => 'Teclado multimídia USB, colorido',
            'preco' => 112.51, 'imagem' => 'img/Teclados/tec10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'teclados'
        ],

        // ========== MOUSES ==========
        21 => [
            'id' => 21, 'nome' => 'Mouse Gamer Sem Fio Attack Shark X3 Paw3395',
            'descricao' => 'Mouse sem fio Bluetooth 2.4G, sensor Paw3395, branco',
            'preco' => 255.54, 'imagem' => 'img/Mouses/mou1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        22 => [
            'id' => 22, 'nome' => 'Mouse Gamer Redragon Cobra Cypher Lite RGB',
            'descricao' => 'Mouse óptico 12400 DPI, RGB, 7 botões',
            'preco' => 83.05, 'imagem' => 'img/Mouses/mou2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        23 => [
            'id' => 23, 'nome' => 'Mouse Gamer XT Racer Rush XTM210 RGB',
            'descricao' => 'Mouse gamer com iluminação RGB',
            'preco' => 59.99, 'imagem' => 'img/Mouses/mou3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        24 => [
            'id' => 24, 'nome' => 'Mouse Gamer HyperX Pulsefire Haste 2',
            'descricao' => 'Mouse ultra-leve 61g, sensor 26000 DPI, branco',
            'preco' => 413.35, 'imagem' => 'img/Mouses/mou4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        25 => [
            'id' => 25, 'nome' => 'Mouse Gamer Trust Helox Preto GXT 928',
            'descricao' => 'Mouse gamer com LED vermelho, design furado',
            'preco' => 52.93, 'imagem' => 'img/Mouses/mou5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        26 => [
            'id' => 26, 'nome' => 'Mouse Gamer Viper Pro 3600 DPI Python',
            'descricao' => 'Mouse gamer 3600 DPI, design ergonômico',
            'preco' => 44.90, 'imagem' => 'img/Mouses/mou6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        27 => [
            'id' => 27, 'nome' => 'Mouse Gamer Attack Shark R1 Paw3311 Tri Mode',
            'descricao' => 'Mouse 18000 DPI, tri-mode, 1000Hz, 400 IPS',
            'preco' => 114.54, 'imagem' => 'img/Mouses/mou7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        28 => [
            'id' => 28, 'nome' => 'Mouse Gamer RGB Led Color Kapbom',
            'descricao' => 'Mouse gamer RGB, KA-609, 6 botões',
            'preco' => 15.90, 'imagem' => 'img/Mouses/mou8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        29 => [
            'id' => 29, 'nome' => 'Mouse Gamer USB Led RGB 6 Botões B-Max',
            'descricao' => 'Mouse 3600 DPI, RGB, 6 botões, para jogos',
            'preco' => 25.90, 'imagem' => 'img/Mouses/mou9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],
        30 => [
            'id' => 30, 'nome' => 'Mouse Gamer Sem Fio Bluetooth Tri Mode',
            'descricao' => 'Mouse recarregável 18000 DPI, tri-mode, laranja',
            'preco' => 113.05, 'imagem' => 'img/Mouses/mou10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'mouses'
        ],

        // ========== HEADSETS ==========
        31 => [
            'id' => 31, 'nome' => 'Headset Gamer Havit H2002d Rosa',
            'descricao' => 'Headset gamer rosa, drivers 53mm, microfone ajustável',
            'preco' => 186.96, 'imagem' => 'img/Headsets/hea1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        32 => [
            'id' => 32, 'nome' => 'Headset Gamer JBL Quantum 100M2',
            'descricao' => 'Headset gamer verde, som JBL Quantum, microfone removível',
            'preco' => 151.05, 'imagem' => 'img/Headsets/hea2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        33 => [
            'id' => 33, 'nome' => 'Headset Gamer Sem Fio Logitech G325 Lightspeed',
            'descricao' => 'Headset sem fio, Lightspeed, branco',
            'preco' => 535.90, 'imagem' => 'img/Headsets/hea3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        34 => [
            'id' => 34, 'nome' => 'Headset Gamer Redragon Cragblade H541',
            'descricao' => 'Headset gamer com LED vermelho, drivers 50mm',
            'preco' => 189.99, 'imagem' => 'img/Headsets/hea4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        35 => [
            'id' => 35, 'nome' => 'Headset Biauricular Intelbras WHS 60 Duo USB',
            'descricao' => 'Headset profissional USB, biauricular, com microfone',
            'preco' => 239.90, 'imagem' => 'img/Headsets/hea5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        36 => [
            'id' => 36, 'nome' => 'Headset Gamer Pcyes Nyra White Ghost',
            'descricao' => 'Headset gamer branco, drivers 50mm',
            'preco' => 96.79, 'imagem' => 'img/Headsets/hea6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        37 => [
            'id' => 37, 'nome' => 'Headset Gamer HyperX Cloud Stinger 2',
            'descricao' => 'Headset gamer, drivers 50mm, som surround DTS',
            'preco' => 199.99, 'imagem' => 'img/Headsets/hea7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        38 => [
            'id' => 38, 'nome' => 'Headset Rise Mode Office 03 Drivers 40mm',
            'descricao' => 'Headset com microfone, drivers 40mm',
            'preco' => 34.99, 'imagem' => 'img/Headsets/hea8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        39 => [
            'id' => 39, 'nome' => 'Headset Gamer ELG 7.1 Surround Channel',
            'descricao' => 'Headset gamer som 7.1 surround',
            'preco' => 231.58, 'imagem' => 'img/Headsets/hea9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],
        40 => [
            'id' => 40, 'nome' => 'Headset Gamer Mizar Preto Warrior',
            'descricao' => 'Headset gamer preto com LED RGB, drivers 50mm',
            'preco' => 99.90, 'imagem' => 'img/Headsets/hea10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'headsets'
        ],

        // ========== MICROFONES ==========
        41 => [
            'id' => 41, 'nome' => 'Microfone Gamer Fifine A8 Ampligame RGB USB',
            'descricao' => 'Microfone USB RGB, cápsula condensadora, tripé',
            'preco' => 229.99, 'imagem' => 'img/Microfones/mic1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        42 => [
            'id' => 42, 'nome' => 'Microfone de Mesa Preto Maxprint',
            'descricao' => 'Microfone de mesa com haste flexível, USB',
            'preco' => 22.49, 'imagem' => 'img/Microfones/mic2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        43 => [
            'id' => 43, 'nome' => 'Microfone Condensador Multimídia para PC com Tripé e Cabo P2',
            'descricao' => 'Microfone condensador com tripé e cabo P2',
            'preco' => 28.90, 'imagem' => 'img/Microfones/mic3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        44 => [
            'id' => 44, 'nome' => 'Microfone Gamer de Mesa Rise Mode Elite 05',
            'descricao' => 'Microfone gamer de mesa, RGB, USB',
            'preco' => 160.58, 'imagem' => 'img/Microfones/mic4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        45 => [
            'id' => 45, 'nome' => 'Microfone Gamer de Mesa Rise Mode Elite 01 RGB',
            'descricao' => 'Microfone gamer com tripé, RGB',
            'preco' => 74.99, 'imagem' => 'img/Microfones/mic5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        46 => [
            'id' => 46, 'nome' => 'HyperX Microfone QuadCast 2',
            'descricao' => 'Microfone condensador USB, LED vermelho, anti-vibração',
            'preco' => 604.99, 'imagem' => 'img/Microfones/mic6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        47 => [
            'id' => 47, 'nome' => 'Microfone de Mesa Vocal VMM145PH Phantom Power Gooseneck 45cm',
            'descricao' => 'Microfone gooseneck 45cm, phantom power',
            'preco' => 316.92, 'imagem' => 'img/Microfones/mic7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        48 => [
            'id' => 48, 'nome' => 'Microfone Dinâmico Gamer Fifine Ampligame RGB Cardióide USB-C',
            'descricao' => 'Microfone dinâmico USB-C, RGB, anti-ruído',
            'preco' => 269.99, 'imagem' => 'img/Microfones/mic8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        49 => [
            'id' => 49, 'nome' => 'Microfone Gamer Fifine Ampligame A6v USB Pop Filter Tripé Branco',
            'descricao' => 'Microfone USB branco, com pop filter e tripé',
            'preco' => 212.00, 'imagem' => 'img/Microfones/mic9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],
        50 => [
            'id' => 50, 'nome' => 'Microfone Greika Condensador Cardióide USB Gk-usm2',
            'descricao' => 'Microfone condensador USB, padrão cardióide',
            'preco' => 143.75, 'imagem' => 'img/Microfones/mic10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'microfones'
        ],

        // ========== WEBCAMS ==========
        51 => [
            'id' => 51, 'nome' => 'Webcam Logitech C920s Full HD Pro 1080p',
            'descricao' => 'Webcam Full HD 1080p, com tampa de privacidade',
            'preco' => 341.61, 'imagem' => 'img/Webcams/web1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        52 => [
            'id' => 52, 'nome' => 'Webcam Brio 500 Full HD Logitech',
            'descricao' => 'Webcam Full HD, cor branca, com tampa de privacidade',
            'preco' => 399.90, 'imagem' => 'img/Webcams/web2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        53 => [
            'id' => 53, 'nome' => 'Webcam Rise Mode Vision 4k 30 Fps',
            'descricao' => 'Webcam 4K, 30fps, com microfone embutido',
            'preco' => 229.99, 'imagem' => 'img/Webcams/web3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        54 => [
            'id' => 54, 'nome' => 'Webcam Intelbras Full HD 60 Fps WCI1080P',
            'descricao' => 'Webcam Full HD, 60fps, com microfone embutido',
            'preco' => 215.76, 'imagem' => 'img/Webcams/web4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        55 => [
            'id' => 55, 'nome' => 'Webcam Intelbras Full HD 60 Fps WCI1080P',
            'descricao' => 'Webcam Full HD, 60fps, com microfone embutido (preta)',
            'preco' => 215.76, 'imagem' => 'img/Webcams/web5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        56 => [
            'id' => 56, 'nome' => 'Webcam Fortrek Vision 20 1080p 30FPS',
            'descricao' => 'Webcam 1080p, 30fps',
            'preco' => 80.53, 'imagem' => 'img/Webcams/web6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        57 => [
            'id' => 57, 'nome' => 'Webcam Full Hd 1080p WB',
            'descricao' => 'Webcam Full HD 1080p, acompanha tripé',
            'preco' => 81.90, 'imagem' => 'img/Webcams/web7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        58 => [
            'id' => 58, 'nome' => 'Webcam Full Hd 1080p Microfone Pc Notebook Home Office',
            'descricao' => 'Webcam Full HD 1080p com microfone embutido',
            'preco' => 29.99, 'imagem' => 'img/Webcams/web8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        59 => [
            'id' => 59, 'nome' => 'Webcam HD 720p C270 Logitech',
            'descricao' => 'Webcam HD 720p, com microfone embutido',
            'preco' => 104.41, 'imagem' => 'img/Webcams/web9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],
        60 => [
            'id' => 60, 'nome' => 'Webcam Logitech C922 Full HD Pro Stream 1080p',
            'descricao' => 'Webcam Full HD 1080p, ideal para streaming',
            'preco' => 449.92, 'imagem' => 'img/Webcams/web10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'webcams'
        ],

        // ========== CADEIRAS ==========
        61 => [
            'id' => 61, 'nome' => 'Cadeira Gamer ThunderX3 TGC12',
            'descricao' => 'Cadeira gamer verde e preta, reclinável',
            'preco' => 1099.99, 'imagem' => 'img/Cadeiras/cad1.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        62 => [
            'id' => 62, 'nome' => 'Cadeira Xtreme Gamers Maximum Preta',
            'descricao' => 'Cadeira gamer preta e vermelha, reclinável',
            'preco' => 569.99, 'imagem' => 'img/Cadeiras/cad2.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        63 => [
            'id' => 63, 'nome' => 'Cadeira Gamer Fox Racer Rgb Com Iluminação Led',
            'descricao' => 'Cadeira gamer com iluminação LED RGB',
            'preco' => 736.00, 'imagem' => 'img/Cadeiras/cad3.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        64 => [
            'id' => 64, 'nome' => 'Cadeira Gamer Ninja Mewmew Pro Edition',
            'descricao' => 'Cadeira gamer rosa, edição especial',
            'preco' => 799.99, 'imagem' => 'img/Cadeiras/cad4.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        65 => [
            'id' => 65, 'nome' => 'Cadeira Gamer Fortt Xiamen',
            'descricao' => 'Cadeira gamer amarela e preta',
            'preco' => 289.00, 'imagem' => 'img/Cadeiras/cad5.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        66 => [
            'id' => 66, 'nome' => 'Cadeira Gamer Husky Tempest 700 hcg700',
            'descricao' => 'Cadeira gamer branca, reclinável',
            'preco' => 749.99, 'imagem' => 'img/Cadeiras/cad6.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        67 => [
            'id' => 67, 'nome' => 'Cadeira Gamer Xtreme Plus Gamer Zone',
            'descricao' => 'Cadeira gamer preta e cinza',
            'preco' => 799.90, 'imagem' => 'img/Cadeiras/cad7.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        68 => [
            'id' => 68, 'nome' => 'Cadeira Gamer Pcyes Mad Racer V8 Turbo',
            'descricao' => 'Cadeira gamer preta, modelo turbo',
            'preco' => 1195.08, 'imagem' => 'img/Cadeiras/cad8.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        69 => [
            'id' => 69, 'nome' => 'ELG Cadeira Gamer Ergonômica Pollux Braço 3D',
            'descricao' => 'Cadeira gamer ergonômica com braço 3D',
            'preco' => 899.90, 'imagem' => 'img/Cadeiras/cad9.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],
        70 => [
            'id' => 70, 'nome' => 'Xperience Cadeira Gamer Ultra Branca Giratória',
            'descricao' => 'Cadeira gamer branca, giratória e ajustável',
            'preco' => 747.91, 'imagem' => 'img/Cadeiras/cad10.jpg',
            'categoria' => 'perifericos', 'subcategoria' => 'cadeiras'
        ],

        // ========== PROCESSADORES ==========
        71 => [
            'id' => 71, 'nome' => 'Processador Intel Core i5-12400F',
            'descricao' => '12ª geração, 6 núcleos, 12 threads',
            'preco' => 899.99, 'imagem' => 'img/Processadores/pro1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        72 => [
            'id' => 72, 'nome' => 'Processador AMD Ryzen 9 7900 AM5',
            'descricao' => '12 núcleos, 24 threads, soquete AM5',
            'preco' => 1996.45, 'imagem' => 'img/Processadores/pro2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        73 => [
            'id' => 73, 'nome' => 'Processador AMD Ryzen 7 5700G 3.8GHz',
            'descricao' => '8 núcleos, 16 threads, com vídeo integrado',
            'preco' => 926.27, 'imagem' => 'img/Processadores/pro3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        74 => [
            'id' => 74, 'nome' => 'Processador Intel Core i7-14700KF',
            'descricao' => '20 núcleos, 28 threads, desbloqueado',
            'preco' => 2049.99, 'imagem' => 'img/Processadores/pro4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        75 => [
            'id' => 75, 'nome' => 'Processador AMD Ryzen 7 9700X',
            'descricao' => '8 núcleos, 16 threads, soquete AM5',
            'preco' => 1641.49, 'imagem' => 'img/Processadores/pro5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        76 => [
            'id' => 76, 'nome' => 'Processador AMD Ryzen 7 3800X AM4 3.9GHz',
            'descricao' => '8 núcleos, 16 threads, soquete AM4',
            'preco' => 1992.90, 'imagem' => 'img/Processadores/pro6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        77 => [
            'id' => 77, 'nome' => 'Processador Intel Core i5-10600KF',
            'descricao' => '10ª geração, 6 núcleos, 12 threads, desbloqueado',
            'preco' => 1129.99, 'imagem' => 'img/Processadores/pro7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        78 => [
            'id' => 78, 'nome' => 'Processador AMD Ryzen 7 7700 AM5',
            'descricao' => '8 núcleos, 16 threads, soquete AM5',
            'preco' => 1888.99, 'imagem' => 'img/Processadores/pro8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        79 => [
            'id' => 79, 'nome' => 'Processador Intel G5925 Celeron',
            'descricao' => '2 núcleos, 2 threads, soquete LGA1200',
            'preco' => 424.28, 'imagem' => 'img/Processadores/pro9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],
        80 => [
            'id' => 80, 'nome' => 'Processador Intel 12900 Core i9',
            'descricao' => '16 núcleos, 24 threads, 12ª geração',
            'preco' => 2631.99, 'imagem' => 'img/Processadores/pro10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'processadores'
        ],

        // ========== PLACAS-MÃE ==========
        81 => [
            'id' => 81, 'nome' => 'Placa Mãe MSI Pro B840M-P WIFI6E DDR5',
            'descricao' => 'Micro-ATX, DDR5, WIFI 6E, soquete AM5',
            'preco' => 699.99, 'imagem' => 'img/Placas-Mãe/plm1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        82 => [
            'id' => 82, 'nome' => 'Placa-Mãe Husky Nexus A520 M.2 NVMe hpm520',
            'descricao' => 'Micro-ATX, soquete AM4, slot M.2 NVMe',
            'preco' => 359.99, 'imagem' => 'img/Placas-Mãe/plm2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        83 => [
            'id' => 83, 'nome' => 'Placa Mãe TGT H310M-T DDR4',
            'descricao' => 'Micro-ATX, soquete LGA1151, DDR4',
            'preco' => 349.99, 'imagem' => 'img/Placas-Mãe/plm3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        84 => [
            'id' => 84, 'nome' => 'Placa Mãe Gigabyte B550M Gaming X V2 AMD AM4',
            'descricao' => 'Micro-ATX, soquete AM4, DDR4',
            'preco' => 580.99, 'imagem' => 'img/Placas-Mãe/plm4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        85 => [
            'id' => 85, 'nome' => 'Asus Placa-Mãe Prime B550M-A',
            'descricao' => 'Micro-ATX, soquete AM4, DDR4',
            'preco' => 559.99, 'imagem' => 'img/Placas-Mãe/plm5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        86 => [
            'id' => 86, 'nome' => 'Placa Mãe Revenger G-H81M',
            'descricao' => 'Micro-ATX, soquete LGA1150, DDR3',
            'preco' => 219.00, 'imagem' => 'img/Placas-Mãe/plm6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        87 => [
            'id' => 87, 'nome' => 'Intel Placa Mãe LGA 1151 Revenger G-H310 Ddr4',
            'descricao' => 'Micro-ATX, soquete LGA1151, DDR4',
            'preco' => 388.08, 'imagem' => 'img/Placas-Mãe/plm7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        88 => [
            'id' => 88, 'nome' => 'Placa Mãe Asus H610M-A Prime H1700 HDMI Ddr5',
            'descricao' => 'Micro-ATX, soquete LGA1700, DDR5',
            'preco' => 509.99, 'imagem' => 'img/Placas-Mãe/plm8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        89 => [
            'id' => 89, 'nome' => 'Placa-Mãe TGT H310M T2 DDR4 LGA1151',
            'descricao' => 'Micro-ATX, soquete LGA1151, DDR4',
            'preco' => 349.99, 'imagem' => 'img/Placas-Mãe/plm9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],
        90 => [
            'id' => 90, 'nome' => 'Asrock Placa-Mãe AM4 B450M Steel Legend',
            'descricao' => 'Micro-ATX, soquete AM4, DDR4',
            'preco' => 665.93, 'imagem' => 'img/Placas-Mãe/plm10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-mae'
        ],

        // ========== PLACAS DE VÍDEO ==========
        91 => [
            'id' => 91, 'nome' => 'Placa de Vídeo PNY Nvidia Quadro T400 GDDR6',
            'descricao' => 'GPU profissional, 2GB GDDR6, 3x Mini DisplayPort',
            'preco' => 1139.99, 'imagem' => 'img/Placas de Video/plv1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        92 => [
            'id' => 92, 'nome' => 'Placa de Vídeo Galax GeForce GT 730 4GB',
            'descricao' => 'GPU de entrada, 4GB, 128 bits',
            'preco' => 344.99, 'imagem' => 'img/Placas de Video/plv2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        93 => [
            'id' => 93, 'nome' => 'Placa de Vídeo Gamer Nvidia Geforce Gtx750 Gddr5 4gb 128bits',
            'descricao' => 'GPU intermediária, 4GB GDDR5, 128 bits',
            'preco' => 507.84, 'imagem' => 'img/Placas de Video/plv3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        94 => [
            'id' => 94, 'nome' => 'Placa de Vídeo Pcyes Nvidia Geforce RTX 3050 6GB Gddr6',
            'descricao' => 'GPU RTX, 6GB GDDR6, ray tracing',
            'preco' => 1529.40, 'imagem' => 'img/Placas de Video/plv4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        95 => [
            'id' => 95, 'nome' => 'PowerColor Placa de Vídeo Power Color RX 580 Radeon Red Drag',
            'descricao' => 'GPU AMD Radeon RX 580',
            'preco' => 1950.72, 'imagem' => 'img/Placas de Video/plv5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        96 => [
            'id' => 96, 'nome' => 'Placa de Vídeo Gigabyte GeForce RTX 2060',
            'descricao' => 'GPU RTX, ray tracing (usado)',
            'preco' => 1334.00, 'imagem' => 'img/Placas de Video/plv6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        97 => [
            'id' => 97, 'nome' => 'Placa de Vídeo MSI GeForce RTX 5050 Gaming OC',
            'descricao' => 'GPU RTX 5050, overclock de fábrica',
            'preco' => 2299.99, 'imagem' => 'img/Placas de Video/plv7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        98 => [
            'id' => 98, 'nome' => 'Placa Gráfica Gaming 4gb Gddr5 Gtx750ti Clock 1020mhz HDMI',
            'descricao' => 'GPU GTX 750 Ti, 4GB GDDR5',
            'preco' => 529.99, 'imagem' => 'img/Placas de Video/plv8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        99 => [
            'id' => 99, 'nome' => 'Placa de Vídeo Asus GeForce RTX 3080 10GB ROG-STRIX',
            'descricao' => 'GPU high-end RTX 3080, 10GB',
            'preco' => 20556.00, 'imagem' => 'img/Placas de Video/plv9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],
        100 => [
            'id' => 100, 'nome' => 'Placa de Vídeo Leadertech Radeon Rx 550',
            'descricao' => 'GPU AMD Radeon RX 550',
            'preco' => 599.90, 'imagem' => 'img/Placas de Video/plv10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'placas-video'
        ],

        // ========== MEMÓRIAS RAM ==========
        101 => [
            'id' => 101, 'nome' => 'Memória Kingston DDR4 Fury Beast',
            'descricao' => 'DDR4, linha Fury Beast, dissipador preto',
            'preco' => 669.99, 'imagem' => 'img/Memorias RAM/mem1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        102 => [
            'id' => 102, 'nome' => 'Memória DDR4 Rise Mode Venon 3200MHz',
            'descricao' => 'DDR4 3200MHz, com RGB',
            'preco' => 459.99, 'imagem' => 'img/Memorias RAM/mem2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        103 => [
            'id' => 103, 'nome' => 'Memória Best Memory 8GB DDR4 3200MHz',
            'descricao' => 'DDR4 8GB, 3200MHz',
            'preco' => 408.00, 'imagem' => 'img/Memorias RAM/mem3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        104 => [
            'id' => 104, 'nome' => 'Memória 16GB DDR5 5600MHz XPG Lancer Blade',
            'descricao' => 'DDR5 16GB, 5600MHz, com RGB',
            'preco' => 1699.99, 'imagem' => 'img/Memorias RAM/mem4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        105 => [
            'id' => 105, 'nome' => 'Memória Corsair DDR4 Vengeance LPX',
            'descricao' => 'DDR4, linha Vengeance LPX, preto',
            'preco' => 618.45, 'imagem' => 'img/Memorias RAM/mem5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        106 => [
            'id' => 106, 'nome' => 'Memória DDR4 3200mhz Rise Mode Z',
            'descricao' => 'DDR4 3200MHz, dissipador',
            'preco' => 446.00, 'imagem' => 'img/Memorias RAM/mem6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        107 => [
            'id' => 107, 'nome' => 'Memoria Gamer Pcyes Udimm 16Gb Ddr4 3200MHz Black',
            'descricao' => 'DDR4 16GB, 3200MHz, preto',
            'preco' => 1125.92, 'imagem' => 'img/Memorias RAM/mem7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        108 => [
            'id' => 108, 'nome' => 'Memória DDR4 8GB Crucial',
            'descricao' => 'DDR4 8GB, Crucial',
            'preco' => 422.70, 'imagem' => 'img/Memorias RAM/mem8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        109 => [
            'id' => 109, 'nome' => 'Memória Ddr4 8GB 3200mhz Team Group T-Force Vulcan Z Cinza',
            'descricao' => 'DDR4 8GB, 3200MHz, cinza',
            'preco' => 499.99, 'imagem' => 'img/Memorias RAM/mem9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],
        110 => [
            'id' => 110, 'nome' => 'Memoria 8GB DDR3 1600MHZ Best Memory',
            'descricao' => 'DDR3 8GB, 1600MHz',
            'preco' => 159.00, 'imagem' => 'img/Memorias RAM/mem10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'memorias-ram'
        ],

        // ========== ARMAZENAMENTO ==========
        111 => [
            'id' => 111, 'nome' => 'Western Digital SSD M.2 Nvme WD Green SN350',
            'descricao' => 'SSD M.2 NVMe, WD Green SN350',
            'preco' => 899.87, 'imagem' => 'img/Armazenamento/ssd1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        112 => [
            'id' => 112, 'nome' => 'SSD Plus Sandisk',
            'descricao' => 'SSD SATA, linha Plus SanDisk',
            'preco' => 351.50, 'imagem' => 'img/Armazenamento/ssd2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        113 => [
            'id' => 113, 'nome' => 'SSD A400 Kingston Sata',
            'descricao' => 'SSD SATA, linha A400 Kingston',
            'preco' => 561.90, 'imagem' => 'img/Armazenamento/ssd3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        114 => [
            'id' => 114, 'nome' => 'SSD 120GB Get Sata',
            'descricao' => 'SSD SATA 120GB, marca Get',
            'preco' => 213.56, 'imagem' => 'img/Armazenamento/ssd4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        115 => [
            'id' => 115, 'nome' => 'HD Ssd Somnambulist 120gb 550Mbps Leitura 500Mbps Gravacao',
            'descricao' => 'SSD SATA 120GB, leitura 550MB/s, gravação 500MB/s',
            'preco' => 169.00, 'imagem' => 'img/Armazenamento/hd5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        116 => [
            'id' => 116, 'nome' => 'SSD Sata Rise Mode Gamer Line',
            'descricao' => 'SSD SATA, linha Gamer Rise Mode',
            'preco' => 254.11, 'imagem' => 'img/Armazenamento/ssd6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        117 => [
            'id' => 117, 'nome' => 'HD Ssd Sata3 120gb Tronos',
            'descricao' => 'SSD SATA3 120GB, marca Tronos',
            'preco' => 197.53, 'imagem' => 'img/Armazenamento/hd7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        118 => [
            'id' => 118, 'nome' => 'Western Digital SSD WD Green 1TB Sata III 2.5 wds100t5g0a',
            'descricao' => 'SSD SATA III 1TB, formato 2.5", WD Green',
            'preco' => 580.00, 'imagem' => 'img/Armazenamento/ssd8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        119 => [
            'id' => 119, 'nome' => 'Ssd Pcyes 1TB M.2 2280 Nvme',
            'descricao' => 'SSD M.2 2280 NVMe, 1TB, Pcyes',
            'preco' => 1167.48, 'imagem' => 'img/Armazenamento/ssd9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],
        120 => [
            'id' => 120, 'nome' => 'SSD PCIe Husky ThunderBoost 2 NVMe',
            'descricao' => 'SSD PCIe NVMe, linha ThunderBoost 2 Husky',
            'preco' => 1364.69, 'imagem' => 'img/Armazenamento/ssd10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'armazenamento'
        ],

        // ========== FONTES ==========
        121 => [
            'id' => 121, 'nome' => 'Fonte Redragon RGPS 500W 80 Plus Bronze',
            'descricao' => '500W, certificação 80 Plus Bronze',
            'preco' => 289.10, 'imagem' => 'img/Fontes/fon1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        122 => [
            'id' => 122, 'nome' => 'Fonte Atx 500W Tgt Tomahawk T3',
            'descricao' => '500W, ATX, linha Tomahawk T3',
            'preco' => 115.99, 'imagem' => 'img/Fontes/fon2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        123 => [
            'id' => 123, 'nome' => 'Fonte Duex DX 600FSE++ 600W 80 Plus Bronze Modular',
            'descricao' => '600W, 80 Plus Bronze, modular',
            'preco' => 249.99, 'imagem' => 'img/Fontes/fon3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        124 => [
            'id' => 124, 'nome' => 'Fonte Gigabyte UD1000GM PG5 V2 1000W 80 PLUS Gold',
            'descricao' => '1000W, 80 Plus Gold, modular',
            'preco' => 858.34, 'imagem' => 'img/Fontes/fon4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        125 => [
            'id' => 125, 'nome' => 'Fonte 80 Plus Bronze Duex DX',
            'descricao' => 'Fonte 80 Plus Bronze, marca Duex',
            'preco' => 162.81, 'imagem' => 'img/Fontes/fon5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        126 => [
            'id' => 126, 'nome' => 'Fonte XPG Core Reactor II VE 850W 80 Plus Gold',
            'descricao' => '850W, 80 Plus Gold, modular',
            'preco' => 655.54, 'imagem' => 'img/Fontes/fon6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        127 => [
            'id' => 127, 'nome' => 'Fonte Atx 600W Real Brazilpc Bpc/g6350-B 24 Pinos',
            'descricao' => '600W real, 24 pinos',
            'preco' => 149.43, 'imagem' => 'img/Fontes/fon7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        128 => [
            'id' => 128, 'nome' => 'Fonte Cougar Atlas 650w 80 Plus Bronze',
            'descricao' => '650W, 80 Plus Bronze',
            'preco' => 279.99, 'imagem' => 'img/Fontes/fon8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        129 => [
            'id' => 129, 'nome' => 'Fonte Gamer Alimentação Pc 750w Silencioso 80 Plus',
            'descricao' => '750W, silenciosa, 80 Plus',
            'preco' => 321.20, 'imagem' => 'img/Fontes/fon9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],
        130 => [
            'id' => 130, 'nome' => 'Fonte ATX 350W Real com Cabo de Força Bivolt Preto',
            'descricao' => '350W real, bivolt, com cabo',
            'preco' => 92.00, 'imagem' => 'img/Fontes/fon10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'fontes'
        ],

        // ========== GABINETES ==========
        131 => [
            'id' => 131, 'nome' => 'Gabinete Gamer Hayom',
            'descricao' => 'Gabinete gamer com vidro lateral e fans RGB',
            'preco' => 237.02, 'imagem' => 'img/Gabinetes/gab1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        132 => [
            'id' => 132, 'nome' => 'Gabinete Gamer Rise Mode Galaxy Glass',
            'descricao' => 'Gabinete gamer com vidro, fans RGB',
            'preco' => 449.99, 'imagem' => 'img/Gabinetes/gab2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        133 => [
            'id' => 133, 'nome' => 'Gabinete Gamer Brx',
            'descricao' => 'Gabinete gamer com vidro lateral',
            'preco' => 179.99, 'imagem' => 'img/Gabinetes/gab3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        134 => [
            'id' => 134, 'nome' => 'Gabinete Gamer Round',
            'descricao' => 'Gabinete gamer mini tower',
            'preco' => 282.34, 'imagem' => 'img/Gabinetes/gab4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        135 => [
            'id' => 135, 'nome' => 'Gabinete Gamer Pichau',
            'descricao' => 'Gabinete gamer com lateral em vidro',
            'preco' => 589.99, 'imagem' => 'img/Gabinetes/gab5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        136 => [
            'id' => 136, 'nome' => 'Gabinete Gamer Hayom Vidro',
            'descricao' => 'Gabinete gamer com lateral de vidro e RGB',
            'preco' => 180.80, 'imagem' => 'img/Gabinetes/gab6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        137 => [
            'id' => 137, 'nome' => 'Gabinete Gamer Husky',
            'descricao' => 'Gabinete gamer branco com vidro e RGB',
            'preco' => 207.65, 'imagem' => 'img/Gabinetes/gab7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        138 => [
            'id' => 138, 'nome' => 'Gabinete Gamer PCYes',
            'descricao' => 'Gabinete gamer com lateral de vidro',
            'preco' => 132.20, 'imagem' => 'img/Gabinetes/gab8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        139 => [
            'id' => 139, 'nome' => 'Gabinete Gamer Murt',
            'descricao' => 'Gabinete gamer com lateral em acrílico',
            'preco' => 94.91, 'imagem' => 'img/Gabinetes/gab9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],
        140 => [
            'id' => 140, 'nome' => 'Gabinete Gamer',
            'descricao' => 'Gabinete gamer com vidro lateral',
            'preco' => 309.98, 'imagem' => 'img/Gabinetes/gab10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'gabinetes'
        ],

        // ========== REFRIGERADORES ==========
        141 => [
            'id' => 141, 'nome' => 'Cooler Duplo RGB CPU Fan Pc Intel AMD 775',
            'descricao' => 'Cooler duplo RGB para CPU Intel/AMD',
            'preco' => 79.50, 'imagem' => 'img/Refrigeradores/ref1.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        142 => [
            'id' => 142, 'nome' => 'Kit de Refrigeradores Universais 3 Fan Gamer',
            'descricao' => 'Kit com 3 fans universais RGB',
            'preco' => 277.98, 'imagem' => 'img/Refrigeradores/ref2.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        143 => [
            'id' => 143, 'nome' => 'Air Cooler Gamer Rise Mode X4 RGB',
            'descricao' => 'Air cooler RGB, recondicionado',
            'preco' => 26.49, 'imagem' => 'img/Refrigeradores/ref3.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        144 => [
            'id' => 144, 'nome' => 'Water Cooler Arctic Liquid Freezer III Pro',
            'descricao' => 'Water cooler Arctic, alta performance',
            'preco' => 739.99, 'imagem' => 'img/Refrigeradores/ref4.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        145 => [
            'id' => 145, 'nome' => 'Cooler Para Processador Pcyes',
            'descricao' => 'Cooler para CPU com RGB',
            'preco' => 129.99, 'imagem' => 'img/Refrigeradores/ref5.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        146 => [
            'id' => 146, 'nome' => 'Water Cooler 240mm Corsair ICUE H100i',
            'descricao' => 'Water cooler 240mm, Corsair iCUE',
            'preco' => 2000.00, 'imagem' => 'img/Refrigeradores/ref6.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        147 => [
            'id' => 147, 'nome' => 'Air Cooler MACH1 ECHO DIGITAL',
            'descricao' => 'Air cooler digital, com display',
            'preco' => 131.99, 'imagem' => 'img/Refrigeradores/ref7.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        148 => [
            'id' => 148, 'nome' => 'Cooler Redragon Buri Led',
            'descricao' => 'Cooler Redragon com LED vermelho',
            'preco' => 87.99, 'imagem' => 'img/Refrigeradores/ref8.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        149 => [
            'id' => 149, 'nome' => 'Refrigerador Aio Asus Tuf Gaming Lc Iii 360',
            'descricao' => 'Water cooler 360mm, ASUS TUF Gaming',
            'preco' => 891.03, 'imagem' => 'img/Refrigeradores/ref9.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],
        150 => [
            'id' => 150, 'nome' => 'Cooler Duplo Processador Cpu RGB',
            'descricao' => 'Cooler duplo para CPU com RGB',
            'preco' => 89.91, 'imagem' => 'img/Refrigeradores/ref10.jpg',
            'categoria' => 'componentes', 'subcategoria' => 'refrigeradores'
        ],

        // ========== CAMISETAS ==========
        151 => [
            'id' => 151, 'nome' => 'Camiseta Oficial Furia',
            'descricao' => 'Camiseta oficial do time Furia, preta com logos',
            'preco' => 249.90, 'imagem' => 'img/Camisetas/cam1.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        152 => [
            'id' => 152, 'nome' => 'Camisa do Roblox Personalizada',
            'descricao' => 'Camiseta Roblox personalizada com nome, infantil',
            'preco' => 59.90, 'imagem' => 'img/Camisetas/cam2.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        153 => [
            'id' => 153, 'nome' => 'Camiseta Minecraft',
            'descricao' => 'Camiseta Minecraft verde com estampa Creeper',
            'preco' => 70.00, 'imagem' => 'img/Camisetas/cam3.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        154 => [
            'id' => 154, 'nome' => 'Camiseta Fortnite Preta De Gola Redonda Com Ajuste Clássico',
            'descricao' => 'Camiseta Fortnite preta, gola redonda',
            'preco' => 89.90, 'imagem' => 'img/Camisetas/cam4.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        155 => [
            'id' => 155, 'nome' => 'Camiseta Free Fire',
            'descricao' => 'Camiseta Free Fire preta e vermelha, estilo esportivo',
            'preco' => 79.90, 'imagem' => 'img/Camisetas/cam5.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        156 => [
            'id' => 156, 'nome' => 'Camiseta Grand Theft Auto IV',
            'descricao' => 'Camiseta GTA IV preta com logo nas costas',
            'preco' => 69.90, 'imagem' => 'img/Camisetas/cam6.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        157 => [
            'id' => 157, 'nome' => 'Camiseta Valorant Jett',
            'descricao' => 'Camiseta Valorant com estampa da personagem Jett',
            'preco' => 89.90, 'imagem' => 'img/Camisetas/cam7.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        158 => [
            'id' => 158, 'nome' => 'Camiseta Yasuo League of Legends',
            'descricao' => 'Camiseta branca com estampa Yasuo do LoL',
            'preco' => 79.90, 'imagem' => 'img/Camisetas/cam8.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        159 => [
            'id' => 159, 'nome' => 'Camiseta Counter-Strike: Global Offensive',
            'descricao' => 'Camiseta CS:GO preta com estampa',
            'preco' => 74.90, 'imagem' => 'img/Camisetas/cam9.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],
        160 => [
            'id' => 160, 'nome' => 'Camiseta Brawl Star',
            'descricao' => 'Camiseta Brawl Stars preta com logo',
            'preco' => 64.90, 'imagem' => 'img/Camisetas/cam10.jpg',
            'categoria' => 'combos', 'subcategoria' => 'camisetas'
        ],

        // ========== KITS ==========
        161 => [
            'id' => 161, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor, teclado, mouse',
            'preco' => 3834.22, 'imagem' => 'img/Kits/kit1.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        162 => [
            'id' => 162, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor 19", teclado, mouse, headset',
            'preco' => 1808.80, 'imagem' => 'img/Kits/kit2.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        163 => [
            'id' => 163, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor, teclado, mouse',
            'preco' => 3140.99, 'imagem' => 'img/Kits/kit3.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        164 => [
            'id' => 164, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor, teclado, mouse',
            'preco' => 1184.04, 'imagem' => 'img/Kits/kit4.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        165 => [
            'id' => 165, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor, teclado, mouse',
            'preco' => 4031.92, 'imagem' => 'img/Kits/kit5.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        166 => [
            'id' => 166, 'nome' => 'PC Game I7 Montado',
            'descricao' => 'PC Gamer i7 montado com monitor, teclado, mouse',
            'preco' => 3973.20, 'imagem' => 'img/Kits/kit6.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        167 => [
            'id' => 167, 'nome' => 'PC Gamer Completo',
            'descricao' => 'PC Gamer completo com monitor, teclado, mouse, headset',
            'preco' => 4199.00, 'imagem' => 'img/Kits/kit7.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        168 => [
            'id' => 168, 'nome' => 'PC Gamer 3green',
            'descricao' => 'PC Gamer com monitor 24", teclado, mouse',
            'preco' => 4145.19, 'imagem' => 'img/Kits/kit8.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        169 => [
            'id' => 169, 'nome' => 'AMD PC Gamer',
            'descricao' => 'PC Gamer AMD com monitor, teclado, mouse, headset',
            'preco' => 5443.33, 'imagem' => 'img/Kits/kit9.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
        170 => [
            'id' => 170, 'nome' => 'PC Gamer Mrp',
            'descricao' => 'PC Gamer com monitor, teclado, mouse',
            'preco' => 2022.37, 'imagem' => 'img/Kits/kit10.jpg',
            'categoria' => 'combos', 'subcategoria' => 'kits'
        ],
    ];
    return $produtos;
}
?>