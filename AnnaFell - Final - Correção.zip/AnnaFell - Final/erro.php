<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Erro no Login - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>
            <a href="index.php">Produtos</a>
            <a href="carrinho.php">Carrinho</a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <div class="af-form-box af-form-box-centro">
        <h2>Erro no Login</h2>
        <p class="af-erro">❌ Usuário ou senha incorretos!</p>
        <p class="af-texto-centro">Por favor, tente novamente.</p>
        <a href="login.php" class="af-btn">Voltar para o Login</a>
    </div>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>