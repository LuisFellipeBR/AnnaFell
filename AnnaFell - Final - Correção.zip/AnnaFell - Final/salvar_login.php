<?php
if(!isset($_SESSION)) {
    session_start();
}
include "cons.php";
require_once "DLL.php";

extract($_POST);
$cpf = $_SESSION['cpf_usuario'] ?? '';

if (empty($cpf)) {
    header("Location: cadastro1.php");
    exit();
}

$senha_criptografada = md5($senha);

$consulta = "INSERT INTO logins (login, senha, cpf) VALUES ('$login', '$senha_criptografada', '$cpf')";
banco($server, $user, $password, $db, $consulta);

unset($_SESSION['cpf_usuario']);
header("Location: login.php?cadastro=ok");
exit();
?>