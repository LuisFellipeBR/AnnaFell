<?php
if(!isset($_SESSION)) {
    session_start();
}
include "cons.php";
require_once "DLL.php";

if (!isset($_SESSION['usuario_logado']) || empty($_SESSION['carrinho'])) {
    header("Location: login.php");
    exit();
}

$carrinho = $_SESSION['carrinho'];
$usuario = $_SESSION['usuario_logado'];
$cpf = $_SESSION['cpf_usuario'];

$consulta = "SELECT nome FROM usuarios WHERE cpf = '$cpf'";
$resultado = banco($server, $user, $password, $db, $consulta);
$nome_usuario = "";
if ($linha = $resultado->fetch_assoc()) {
    $nome_usuario = $linha['nome'];
}

$total = 0;
foreach ($carrinho as $item) {
    $total += $item['preco'] * $item['quantidade'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Compra - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>
            <a href="index.php">Produtos</a>
            <a href="carrinho.php">Carrinho</a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <div class="af-form-box af-form-box-grande">
        <h2>✅ Confirmação da Compra</h2>

        <div class="af-info-usuario">
            <p><strong class="af-destaque-texto">Usuário:</strong> <?php echo $nome_usuario; ?></p>
            <p><strong class="af-destaque-texto">Login:</strong> <?php echo $usuario; ?></p>
        </div>

        <p class="af-destaque-texto af-negrito">Itens do pedido:</p>
        <div class="af-itens-confirmacao">
            <?php foreach($carrinho as $item): ?>
            <div class="af-item-confirmacao">
                <img src="<?php echo $item['imagem']; ?>" class="af-item-img-confirmacao">
                <div>
                    <strong><?php echo $item['nome']; ?></strong><br>
                    Quantidade: <?php echo $item['quantidade']; ?><br>
                    Preço unitário: R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?><br>
                    Subtotal: R$ <?php echo number_format($item['preco'] * $item['quantidade'], 2, ',', '.'); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <p class="af-total-final"><strong>Total: R$ <?php echo number_format($total, 2, ',', '.'); ?></strong></p>

        <form method="POST" action="salvar_venda.php">
            <div class="af-campo">
                <label>Forma de Pagamento:</label>
                <select name="pagamento" required>
                    <option value="">Selecione...</option>
                    <option value="Cartão de Crédito">Cartão de Crédito</option>
                    <option value="Cartão de Débito">Cartão de Débito</option>
                    <option value="Boleto Bancário">Boleto Bancário</option>
                    <option value="Pix">Pix</option>
                </select>
            </div>
            <button type="submit" class="af-btn">Confirmar Compra</button>
        </form>

        <div class="af-botoes-laterais">
            <a class="af-btn-login" href="carrinho.php">← Voltar ao carrinho</a>
            <a class="af-btn-login" href="index.php">Continuar comprando</a>
        </div>
    </div>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>