<?php
if(!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - Etapa 1 - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>
            <a href="index.php">Produtos</a>
            <a href="carrinho.php">Carrinho</a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <div class="af-form-box">
        <h2>Cadastro - Etapa 1</h2>

        <form method="POST" action="salvar_usuario.php">
            <div class="af-campo">
                <label>Nome Completo:</label>
                <input type="text" name="nome" required>
            </div>
            <div class="af-campo">
                <label>CPF:</label>
                <input type="text" name="cpf" required placeholder="Apenas números">
            </div>
            <div class="af-campo">
                <label>Endereço:</label>
                <input type="text" name="endereco" required>
            </div>
            <div class="af-campo">
                <label>Bairro:</label>
                <input type="text" name="bairro" required>
            </div>
            <div class="af-campo">
                <label>Cidade:</label>
                <input type="text" name="cidade" required>
            </div>
            <div class="af-campo">
                <label>Estado:</label>
                <input type="text" name="estado" required maxlength="2">
            </div>
            <div class="af-campo">
                <label>CEP:</label>
                <input type="text" name="cep" required>
            </div>
            <button type="submit" class="af-btn">Próxima Etapa</button>
        </form>
    </div>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>