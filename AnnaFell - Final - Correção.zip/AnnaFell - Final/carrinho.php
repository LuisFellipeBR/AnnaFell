<?php
if(!isset($_SESSION)) {
    session_start();
}
require_once 'produtos.php';
$produtos = getProdutos();

$subcategorias_por_categoria = [
    'perifericos' => [
        'monitores'  => 'Monitores',
        'teclados'   => 'Teclados',
        'mouses'     => 'Mouses',
        'headsets'   => 'Headsets',
        'microfones' => 'Microfones',
        'webcams'    => 'Webcams',
        'cadeiras'   => 'Cadeiras'
    ],
    'componentes' => [
        'processadores'  => 'Processadores',
        'placas-mae'     => 'Placas-Mãe',
        'placas-video'   => 'Placas de Vídeo',
        'memorias-ram'   => 'Memórias RAM',
        'armazenamento'  => 'Armazenamento',
        'fontes'         => 'Fontes',
        'gabinetes'      => 'Gabinetes',
        'refrigeradores' => 'Refrigeradores'
    ],
    'combos' => [
        'camisetas' => 'Camisetas',
        'kits'      => 'Kits'
    ]
];

if (!isset($_SESSION['carrinho'])) 
    $_SESSION['carrinho'] = [];

if (isset($_GET['adicionar'])) {
    $id = (int)$_GET['adicionar'];
    if (isset($produtos[$id])) {
        if (isset($_SESSION['carrinho'][$id])) {
            $_SESSION['carrinho'][$id]['quantidade']++;
        } else {
            $_SESSION['carrinho'][$id] = [
                'nome' => $produtos[$id]['nome'],
                'preco' => $produtos[$id]['preco'],
                'imagem' => $produtos[$id]['imagem'],
                'quantidade' => 1
            ];
        }
    }
    header("Location: carrinho.php");
    exit();
}

if (isset($_POST['remover'])) {
    unset($_SESSION['carrinho'][(int)$_POST['remover']]);
    header("Location: carrinho.php");
    exit();
}

if (isset($_POST['atualizar'])) {
    foreach ($_POST['quantidade'] as $id => $qtd) {
        $id = (int)$id;
        $qtd = (int)$qtd;
        if ($qtd <= 0) unset($_SESSION['carrinho'][$id]);
        else $_SESSION['carrinho'][$id]['quantidade'] = $qtd;
    }
    header("Location: carrinho.php");
    exit();
}

if (isset($_POST['finalizar']) && !empty($_SESSION['carrinho'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meu Carrinho - AnnaFell</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="af-topo-site">
    <img src="img/banner.jpg" alt="AnnaFell Banner" class="af-banner-principal">
</div>

<div class="af-navbar">
    <div class="af-nav-container">
        <div class="af-nav-links">
            <a href="index.php">Página Inicial</a>

            <div class="af-dropdown">
                <a>Produtos ▼</a>
                <div class="af-dropdown-content">
                    <div class="af-submenu">
                        <a href="index.php?categoria=perifericos">Periféricos ▶</a>
                        <div class="af-submenu-content">
                            <?php foreach ($subcategorias_por_categoria['perifericos'] as $slug => $nome): ?>
                                <a href="index.php?categoria=perifericos&subcategoria=<?php echo $slug; ?>"><?php echo $nome; ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="af-submenu">
                        <a href="index.php?categoria=componentes">Componentes ▶</a>
                        <div class="af-submenu-content">
                            <?php foreach ($subcategorias_por_categoria['componentes'] as $slug => $nome): ?>
                                <a href="index.php?categoria=componentes&subcategoria=<?php echo $slug; ?>"><?php echo $nome; ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="af-submenu">
                        <a href="index.php?categoria=combos">Combos ▶</a>
                        <div class="af-submenu-content">
                            <?php foreach ($subcategorias_por_categoria['combos'] as $slug => $nome): ?>
                                <a href="index.php?categoria=combos&subcategoria=<?php echo $slug; ?>"><?php echo $nome; ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <a href="carrinho.php">Carrinho <?php if(!empty($_SESSION['carrinho'])) echo '('.array_sum(array_column($_SESSION['carrinho'], 'quantidade')).')'; ?></a>
            <a href="contato.php">Contato</a>
            <a href="sobre.php">Sobre nós</a>
        </div>
    </div>
</div>

<div class="af-container">
    <h1 class="af-secao-titulo">Meu Carrinho</h1>

    <?php if (empty($_SESSION['carrinho'])): ?>
        <div class="af-carrinho-vazio">
            <p>Seu carrinho está vazio.</p>
            <a href="index.php" class="af-btn">Continuar Comprando</a>
        </div>
    <?php else: ?>
        <form method="POST">
            <div class="af-carrinho-tabela">
                <div class="af-carrinho-linha af-cabecalho">
                    <div class="af-celula-produto">Produto</div>
                    <div class="af-celula-preco">Preço</div>
                    <div class="af-celula-quantidade">Quantidade</div>
                    <div class="af-celula-subtotal">Subtotal</div>
                    <div class="af-celula-acao"></div>
                </div>
                <?php 
                $total = 0;
                foreach ($_SESSION['carrinho'] as $id => $item):
                    $subtotal = $item['preco'] * $item['quantidade'];
                    $total += $subtotal;
                ?>
                <div class="af-carrinho-linha">
                    <div class="af-celula-produto">
                        <img src="<?php echo $item['imagem']; ?>" class="af-carrinho-img">
                        <?php echo $item['nome']; ?>
                    </div>
                    <div class="af-celula-preco">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></div>
                    <div class="af-celula-quantidade">
                        <input type="number" name="quantidade[<?php echo $id; ?>]" value="<?php echo $item['quantidade']; ?>" min="1" class="af-input-quantidade">
                    </div>
                    <div class="af-celula-subtotal">R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></div>
                    <div class="af-celula-acao">
                        <button type="submit" name="remover" value="<?php echo $id; ?>" class="af-btn-remover">Remover</button>
                    </div>
                </div>
                <?php endforeach; ?>
                <div class="af-carrinho-total">
                    <div>Total:</div>
                    <div class="af-total-valor">R$ <?php echo number_format($total, 2, ',', '.'); ?></div>
                </div>
            </div>
            <div class="af-carrinho-acoes">
                <button type="submit" name="atualizar" class="af-btn af-btn-auto">Atualizar Quantidades</button>
                <button type="submit" name="finalizar" class="af-btn-finalizar">Finalizar Compra</button>
                <a href="index.php" class="af-btn-voltar">Continuar Comprando</a>
            </div>
        </form>
    <?php endif; ?>
</div>

<div id="af-rodape">Desenvolvido por Anna Engelhardt e Luís Brito © 2026</div>

</body>
</html>